/**
 * Other interfaces
 */

export type BGender = "Buck" | "Doe";
