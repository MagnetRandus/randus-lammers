import { BGender } from "./BGender";

interface IBB {
  id: number;
  dateOfBirth?: string;
  gender: BGender;
  dam?: number;
  sire?: number;
}

export default IBB;
