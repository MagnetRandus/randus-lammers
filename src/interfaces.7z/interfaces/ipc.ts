export interface IPCLogWrite {
  Label: string;
  Message: string;
}
