interface IIBBForm {
  id: string;
  dateOfBirth: Date | undefined;
  sire: string;
  dam: string;
  gender: string;
}

export default IIBBForm;
