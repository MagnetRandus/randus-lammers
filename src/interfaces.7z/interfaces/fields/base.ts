// import { IBaseField } from "../i-item";

// interface IIBBForm extends Partial<IBaseField> {
//   dateOfBirth: string;
//   sire: number;
//   dam: number;
//   gender: string;
// }

// type WithLookupId<T> = T & { sireLookupId: number; damLookupId: number };
// type RemoveReadableLookups<T> = Omit<T, "sire" | "dam">;

// type WithChangedTypes<T> = {
//   [K in keyof T]: K extends "sireLookupId" | "damLookupId" ? number : T[K];
// };
// export type IIBBFormCU = WithChangedTypes<
//   WithLookupId<RemoveReadableLookups<IIBBForm>>
// >;
// export type IIBBFormRead = WithChangedTypes<WithLookupId<IIBBForm>>;
